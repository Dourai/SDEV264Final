package com.example.expensetracker
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondaryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)

        // Retrieve the values passed from MainActivity
        val starter = intent.getDoubleExtra("STARTER", 0.0)
        val spentToday = intent.getDoubleExtra("SPENT_TODAY", 0.0)
        val amountEntered = intent.getDoubleExtra("AMOUNT_ENTERED", 0.0) // Retrieve "amountEntered" from Intent

        // Calculate the remaining amount
        val remainingAmount = spentToday - amountEntered

        // Access the EditText views by their IDs
        val editTextNumberDecimal2 = findViewById<EditText>(R.id.editTextNumberDecimal2)
        val editTextNumberDecimal3 = findViewById<EditText>(R.id.editTextNumberDecimal3)

        // Set the text of the EditText views
        editTextNumberDecimal2.setText(remainingAmount.toString())

        // Find the buttons by their IDs
        val goHomeButton: Button = findViewById(R.id.button)
        val helpButton: Button = findViewById(R.id.button2)

        // Set click listener for Go Home button
        goHomeButton.setOnClickListener {
            // Create an intent to navigate back to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Set click listener for Help button
        helpButton.setOnClickListener {
            // Create an intent to navigate to HelpActivity
            val intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)
        }
    }
}