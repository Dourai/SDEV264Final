package com.example.expensetracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var starter: Double = 0.0 // Variable to store the current account balance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val helpButton: Button = findViewById(R.id.HelpNav)
        val spentEditText: EditText = findViewById(R.id.spent)
        val doneButton: ImageButton = findViewById(R.id.Done) // Get reference to the "Done" button
        val prefButton: Button = findViewById(R.id.button4) // Get reference to the "Pref" button

        helpButton.setOnClickListener {
            openHelpActivity()
        }

        doneButton.setOnClickListener {
            // Start SecondaryActivity when "Done" button is clicked
            val intent = Intent(this, SecondaryActivity::class.java)
            startActivity(intent)
        }

        prefButton.setOnClickListener {
            // Start PreferencesActivity when "Pref" button is clicked
            val intent = Intent(this, PreferencesActivity::class.java)
            startActivity(intent)
        }

        // Handling button click to update account balance
        findViewById<Button>(R.id.Done).setOnClickListener {
            val amountEntered = intent.getDoubleExtra("amountEntered", 0.0) // Retrieve "amountEntered" from Intent
            val spentToday = spentEditText.text.toString().toDoubleOrNull() ?: 0.0

            // Update starter (current account balance)
            starter = spentToday - amountEntered
        }

        // Setting hint for the spentEditText using string resource
        spentEditText.hint = getString(R.string.spent)
    }

    private fun openHelpActivity() {
        val intent = Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }
}