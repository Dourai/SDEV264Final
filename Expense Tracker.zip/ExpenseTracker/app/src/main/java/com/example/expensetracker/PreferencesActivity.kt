package com.example.expensetracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class PreferencesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        // Find the "Back to Home" button by its ID
        val backButton: Button = findViewById(R.id.backToHomeButton)
        // Find the EditText for balance by its ID
        val balanceEditText: EditText = findViewById(R.id.editTextNumberDecimal)

        // Set OnClickListener for the "Back to Home" button
        backButton.setOnClickListener {
            // Retrieve the text entered in the balance EditText
            val balanceEntered = balanceEditText.text.toString().toDoubleOrNull() ?: 0.0

            // Create an intent to start the MainActivity
            val intent = Intent(this, MainActivity::class.java)
            // Pass the balanceEntered value back to MainActivity as "amountEntered" using Intent extra
            intent.putExtra("amountEntered", balanceEntered)
            // Start the MainActivity
            startActivity(intent)

            // Finish the PreferencesActivity to prevent it from being added to the stack again
            finish()
        }
    }
}